-- MySQL dump 10.11
--
-- Host: localhost    Database: placard
-- ------------------------------------------------------
-- Server version	5.0.77-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jboard_comment`
--

DROP TABLE IF EXISTS `jboard_comment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jboard_comment` (
  `seq` int(10) NOT NULL auto_increment COMMENT '고유번호:자동증가',
  `bid` varchar(20) NOT NULL default '',
  `pid` int(10) NOT NULL default '0' COMMENT '게시판:글번호',
  `mb_id` varchar(20) default NULL,
  `mb_pw` varchar(40) default NULL,
  `mb_name` varchar(20) default NULL,
  `txt_comment` text,
  `cnt_good` int(10) default NULL,
  `cnt_bad` int(10) default NULL,
  `log_ctime` datetime default NULL,
  `log_ip` varchar(20) default NULL,
  `misc_01` varchar(100) default NULL,
  `misc_02` varchar(100) default NULL,
  `misc_03` varchar(100) default NULL,
  `misc_04` varchar(100) default NULL,
  `misc_05` varchar(100) default NULL,
  `misc_06` varchar(100) default NULL,
  `misc_07` varchar(100) default NULL,
  `misc_08` varchar(100) default NULL,
  `misc_09` varchar(100) default NULL,
  `misc_10` varchar(100) default NULL,
  PRIMARY KEY  (`seq`),
  KEY `bid` (`bid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `jboard_comment`
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-29  5:42:56
