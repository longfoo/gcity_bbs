-- MySQL dump 10.11
--
-- Host: localhost    Database: placard
-- ------------------------------------------------------
-- Server version	5.0.77-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jboard_file`
--

DROP TABLE IF EXISTS `jboard_file`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jboard_file` (
  `seq` int(10) NOT NULL default '0' COMMENT '고유번호:20억',
  `pseq` int(10) NOT NULL default '0' COMMENT '게시판:글번호',
  `bid` varchar(20) NOT NULL default '' COMMENT '게시판:아이디',
  `file_save_name` varchar(200) NOT NULL default '' COMMENT '파일:저장이름',
  `file_real_name` varchar(200) NOT NULL default '' COMMENT '파일:원본이름',
  `file_mime` varchar(50) default NULL,
  `file_byte` varchar(15) default NULL,
  `file_memo` varchar(200) NOT NULL default '' COMMENT '파일:메모',
  `cnt_download` int(10) NOT NULL default '0' COMMENT '다운로드수량',
  PRIMARY KEY  (`seq`),
  KEY `idx_bid_seq` (`bid`,`pseq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `jboard_file`
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-29  5:44:01
