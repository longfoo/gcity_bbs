-- MySQL dump 10.11
--
-- Host: localhost    Database: placard
-- ------------------------------------------------------
-- Server version	5.0.77-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jboard_conf`
--

DROP TABLE IF EXISTS `jboard_conf`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jboard_conf` (
  `bid` varchar(20) NOT NULL default '' COMMENT '게시판아이디',
  `bname` varchar(200) NOT NULL default '' COMMENT '게시판이름',
  `priv_list` int(2) NOT NULL default '0' COMMENT '권한:목록',
  `priv_read` int(2) NOT NULL default '1' COMMENT '권한:읽기',
  `priv_write` int(2) NOT NULL default '1' COMMENT '권한:쓰기',
  `priv_reply` int(2) NOT NULL default '1' COMMENT '권한:답변',
  `priv_download` int(2) NOT NULL default '1' COMMENT '권한:다운로드',
  `priv_url` int(2) NOT NULL default '0' COMMENT '권한:링크',
  `priv_comment` int(2) default '1' COMMENT '권한:꼬리글',
  `is_reply` enum('y','n') NOT NULL default 'n' COMMENT '설정:답변여부',
  `is_file` enum('y','n') NOT NULL default 'n' COMMENT '설정:업로드',
  `is_file_cnt` int(2) NOT NULL default '1' COMMENT '설정:업로드수량',
  `is_file_new` enum('y','n') character set euckr NOT NULL default 'n' COMMENT '파일업로드 신형 html5',
  `is_url` enum('y','n') NOT NULL default 'n' COMMENT '설정:링크',
  `is_url_cnt` int(2) NOT NULL default '1' COMMENT '설정:링크수량',
  `is_comment` enum('y','n') NOT NULL default 'y' COMMENT '설정:꼬리글',
  `is_secret` enum('y','n') NOT NULL default 'n' COMMENT '설정:비밀글',
  `is_html` enum('y','n') NOT NULL default 'n' COMMENT '설정:에디터',
  `is_html_editor` varchar(30) default 'smarteditor2',
  `is_tag` enum('y','n') NOT NULL default 'n' COMMENT '설정:태그',
  `is_search` enum('y','n') NOT NULL default 'n' COMMENT '설정:검색기능',
  `is_category` enum('y','n') NOT NULL default 'n' COMMENT '설정:분류사용',
  `category` text COMMENT '분류명칭들',
  `is_gallery` enum('y','n') NOT NULL default 'n' COMMENT '설정:갤러리',
  `is_gallery_cnt` int(2) NOT NULL default '4' COMMENT '설정:갤러리가로수량',
  `is_gallery_img_w` int(3) NOT NULL default '160' COMMENT '설정:갤러리이미지폭',
  `num_width` int(4) NOT NULL default '96' COMMENT '설정:게시판가로폭',
  `num_subject` int(3) NOT NULL default '40' COMMENT '설정:제목글자자르기',
  `num_list` int(3) NOT NULL default '20' COMMENT '설정:페이지당글수',
  `num_image_width` int(4) NOT NULL default '600' COMMENT '설정:이미지보기폭',
  `is_read_list` enum('y','n') NOT NULL default 'n' COMMENT '설정:읽기화면에목록표시',
  `is_write_list` enum('y','n') NOT NULL default 'n' COMMENT '설정:쓰기화면에목록표시',
  `block_ip` text COMMENT '설정:접근금지',
  `misc_01` varchar(100) default NULL COMMENT '기타',
  `misc_02` varchar(100) default NULL COMMENT '기타',
  `misc_03` varchar(100) default NULL COMMENT '기타',
  `misc_04` varchar(100) default NULL COMMENT '기타',
  `misc_05` varchar(100) default NULL COMMENT '기타',
  `misc_06` varchar(100) default NULL COMMENT '기타',
  `misc_07` varchar(100) default NULL COMMENT '기타',
  `misc_08` varchar(100) default NULL COMMENT '기타',
  `misc_09` varchar(100) default NULL COMMENT '기타',
  `misc_10` varchar(100) default NULL COMMENT '기타',
  `misc_01_yn` enum('y','n') NOT NULL default 'n',
  `misc_02_yn` enum('y','n') NOT NULL default 'n',
  `misc_03_yn` enum('y','n') NOT NULL default 'n',
  `misc_04_yn` enum('y','n') NOT NULL default 'n',
  `misc_05_yn` enum('y','n') NOT NULL default 'n',
  `misc_06_yn` enum('y','n') NOT NULL default 'n',
  `misc_07_yn` enum('y','n') NOT NULL default 'n',
  `misc_08_yn` enum('y','n') NOT NULL default 'n',
  `misc_09_yn` enum('y','n') NOT NULL default 'n',
  `misc_10_yn` enum('y','n') NOT NULL default 'n',
  `admin` varchar(100) default NULL COMMENT '관리자아이디',
  `skin` varchar(50) NOT NULL default 'basic_board' COMMENT '스킨이름',
  `inc_header` varchar(100) default NULL COMMENT '상단파일',
  `inc_footer` varchar(100) default NULL COMMENT '하단파일',
  `inc_header_html` text,
  `inc_footer_html` text,
  `is_field_mail` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:메일',
  `is_field_tel` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:전화',
  `is_field_fax` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:팩스',
  `is_field_mobile` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:휴대폰',
  `is_field_home` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:홈페이지',
  `is_field_date` enum('y','n') NOT NULL default 'n' COMMENT '필드설정:날짜입력란',
  `is_title_set` set('subject','name','date','read') NOT NULL default 'subject,name,date,read' COMMENT '제목줄:표시선택',
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `jboard_conf`
--

LOCK TABLES `jboard_conf` WRITE;
/*!40000 ALTER TABLE `jboard_conf` DISABLE KEYS */;
INSERT INTO `jboard_conf` VALUES ('download','자료실',0,0,10,10,0,0,10,'n','y',2,'n','n',1,'n','y','n','smarteditor2','n','n','n','교육신청;컨설팅;식품안전연구소;회원정보;기타','n',4,200,100,40,20,800,'n','n','','','','','','','','','','','','n','n','n','n','n','n','n','n','n','n','','notice_v2','','',' ','','n','n','n','n','n','n','subject,name,date,read'),('faq','FAQ',0,0,10,10,0,0,10,'n','n',1,'n','n',1,'n','y','n','smarteditor2','n','n','y','교육신청;컨설팅;식품안전연구소;회원정보;기타','n',4,200,100,40,20,800,'n','n','','','','','','','','','','','','n','n','n','n','n','n','n','n','n','n','','faq_v2','','','<p>&nbsp;</p>','','y','y','n','y','n','n','subject,name,date,read'),('notice','공지사항',0,0,10,10,0,0,10,'n','y',1,'n','n',1,'n','y','n','smarteditor2','n','n','n','교육신청;컨설팅;식품안전연구소;회원정보;기타','n',4,200,100,40,20,800,'n','n','','','','','','','','','','','','n','n','n','n','n','n','n','n','n','n','','notice_v2','','',' ','','n','n','n','n','n','n','subject,name,date,read'),('test','TEST',0,0,10,10,0,0,10,'y','y',1,'n','n',1,'y','n','n','smarteditor2','n','n','n','','n',4,200,100,40,20,800,'y','n','','','','','','','','','','','','n','n','n','n','n','n','n','n','n','n','','board_v2','','','<p>&nbsp;</p>',NULL,'n','n','n','n','n','n','subject,name,date,read');
/*!40000 ALTER TABLE `jboard_conf` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-29  5:43:26
