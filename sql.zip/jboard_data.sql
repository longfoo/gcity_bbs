-- MySQL dump 10.11
--
-- Host: localhost    Database: placard
-- ------------------------------------------------------
-- Server version	5.0.77-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jboard_data`
--

DROP TABLE IF EXISTS `jboard_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jboard_data` (
  `seq` int(10) NOT NULL default '2000000000' COMMENT 'PK:20억-일련번호',
  `bid` varchar(20) NOT NULL COMMENT '게시판코드',
  `pid` int(10) NOT NULL default '0' COMMENT 'IDX:20억-부모글번호',
  `thread` varchar(255) character set utf8 collate utf8_bin NOT NULL default '' COMMENT 'IDX:답변글',
  `div` int(8) NOT NULL default '1000000' COMMENT 'IDX:DIV',
  `mb_id` varchar(20) NOT NULL COMMENT '글쓴이:아이디',
  `mb_name` varchar(20) NOT NULL COMMENT '글쓴이:성명',
  `mb_pw` varchar(40) NOT NULL COMMENT '비밀번호:md5',
  `mb_tel` varchar(16) default NULL COMMENT '글쓴이:전화',
  `mb_mobile` varchar(16) default NULL COMMENT '글쓴이:휴대폰',
  `mb_fax` varchar(16) default NULL COMMENT '글쓴이:fax',
  `mb_mail` varchar(50) default NULL COMMENT '글쓴이:메일',
  `mb_home` varchar(100) default NULL COMMENT '글쓴이:홈페이지',
  `txt_subject` varchar(200) NOT NULL default '' COMMENT '글:제목',
  `txt_body` longtext COMMENT '글:본문',
  `txt_tag` varchar(200) NOT NULL default '' COMMENT '글:태그',
  `txt_category` varchar(10) NOT NULL default '' COMMENT '글:분류',
  `file_cnt` int(2) NOT NULL default '0' COMMENT '파일:갯수',
  `url_cnt` int(2) NOT NULL default '0' COMMENT '링크:갯수',
  `comment_cnt` int(10) NOT NULL default '0' COMMENT '꼬리글:갯수',
  `is_secret` enum('y','n') NOT NULL default 'n' COMMENT 'YN:비밀글',
  `is_html` enum('y','n') NOT NULL default 'n' COMMENT 'YN:HTML형식',
  `is_notice` enum('y','n') NOT NULL default 'n' COMMENT 'YN:공지글',
  `log_date` varchar(20) default NULL COMMENT '작성일(수기)',
  `log_ctime` datetime NOT NULL COMMENT '기록:글쓴시각',
  `log_mtime` datetime NOT NULL COMMENT '기록:수정시각',
  `log_read` int(10) NOT NULL default '0' COMMENT '기록:조회수',
  `log_yes` int(10) NOT NULL default '0' COMMENT '기록:추천수',
  `log_no` int(10) NOT NULL default '0' COMMENT '기록:반대수',
  `log_ip` varchar(20) default NULL,
  `log_agent` varchar(255) default NULL,
  `misc_01` varchar(255) default NULL,
  `misc_02` varchar(255) default NULL,
  `misc_03` varchar(255) default NULL,
  `misc_04` varchar(255) default NULL,
  `misc_05` varchar(255) default NULL,
  `misc_06` varchar(255) default NULL,
  `misc_07` varchar(255) default NULL,
  `misc_08` varchar(255) default NULL,
  `misc_09` varchar(255) default NULL,
  `misc_10` varchar(255) default NULL,
  `text_01` mediumtext,
  `text_02` mediumtext,
  `text_03` mediumtext,
  `text_04` mediumtext,
  `text_05` mediumtext,
  PRIMARY KEY  (`seq`),
  KEY `bid` (`bid`),
  KEY `pid` (`pid`),
  KEY `thread` (`thread`),
  KEY `div` (`div`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `jboard_data`
--


/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-29  5:43:44
