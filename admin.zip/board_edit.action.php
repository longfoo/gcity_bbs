<?
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################



//print_r($_POST); exit;


//-------------------------------------------------------------------------------------
// POST 변수 검사
//-------------------------------------------------------------------------------------


if( empty($_POST['bid']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

$pattern = "/^[-a-z0-9_]{2,20}$/";

if( preg_match( $pattern,$_POST['bid']) ) {
} else {
	echo "<script>alert( '" . __LINE__ . " 게시판의 코드가 올바르지 않습니다.   '); history.back(); </script>\n";
	exit;
}

if( empty($_POST['bname']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 제목이 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}


//-------------------------------------------------------------------------------------
// 테이블 코드 중복 검사
//-------------------------------------------------------------------------------------

/*
	기존 게시판 정보를 변경하므로 중복검사 필요없음
*/



//-------------------------------------------------------------------------------------
//  board_conf 생성
//-------------------------------------------------------------------------------------

$_INSERT = array();


//$_INSERT['bid'] = $table_to;
$_INSERT['bname'] = $_POST['bname'];

// 사본을 넣기 위한 배열 작업

foreach( $_POST as $key=>$val ) {
	if($key=='tbl') continue;
	if($key=='bid') continue;

    # 하나로 합쳐질 칼럼 : 아래 제목줄 표시설정에서 저장함
	if($key=='is_title_set_subject') continue;
	if($key=='is_title_set_name') continue;
	if($key=='is_title_set_date') continue;
	if($key=='is_title_set_read') continue;

	$_INSERT[ $key ] = $val;
}


#---------------------------------------------------------
# 추가항목 선택여부 : misc_01_yn ~ misc_10_yn
#---------------------------------------------------------

for($i=1; $i<=10; $i++) {
    $tmp_key = "misc_". sprintf("%02s",$i) ."_yn";
    if($_POST[$tmp_key]=="y") {
        $_INSERT[$tmp_key] = "y";
    } else {
        $_INSERT[$tmp_key] = "n";
    }
}

#---------------------------------------------------------
# 제목줄 표시 설정 (2018-10-24)
#---------------------------------------------------------
$_INSERT['is_title_set'] = 0;

if($_POST['is_title_set_subject']=="y") {
    $_INSERT['is_title_set'] += 1;
}
if($_POST['is_title_set_name']=="y") {
    $_INSERT['is_title_set'] += 2;
}
if($_POST['is_title_set_date']=="y") {
    $_INSERT['is_title_set'] += 4;
}
if($_POST['is_title_set_read']=="y") {
    $_INSERT['is_title_set'] += 8;
}

#---------------------------------------------------------
# 기본항목 설정 { 메일, 전화, 팩스, 휴대전화, 홈페이지, 작성일자 }
#---------------------------------------------------------
# radio, checkbox를 사용하는 경우 선택하지 않으면 값이 POST로 넘어오지 않는다.
# 따라서 선택값(y)를 기준으로 검사하고, 선택하지 않은 경우의 값(n)도 저장해줘야 한다.
#---------------------------------------------------------

$tmp_array = array('is_field_mail', 'is_field_tel', 'is_field_fax', 'is_field_mobile', 'is_field_home', 'is_field_date', );

foreach($tmp_array as $key=>$val) {
    if($_POST[ $val ]=="y") {
        $_INSERT[ $val ] = "y";
    } else {
        $_INSERT[ $val ] = "n";
    }
}

#---------------------------------------------------------
# DB 저장
#---------------------------------------------------------

//$query = " INSERT INTO `". BBS_TBL_PREFIX ."conf` SET ";
$query = " UPDATE `". BBS_TBL_PREFIX ."conf` SET ";
$idx = 0;
foreach( $_INSERT as $key=>$val ) {
	if($idx>0) $query.= ", ";
	$query .= "`".$key."`='".$val."'";
	$idx++;
}
$query .= " WHERE `bid`='".$_POST['bid']."' ";
//echo $query."<br><br>\n"; exit;


$result = mysql_query($query);

if (!$result) {
	//echo ("<script>alert('작업 오류입니다.\\n\\n에러코드 = DB_".__LINE__."     '); history.back()</script>\n\n");
	echo mysql_error();
	echo "<br><br>\n";
	echo $query; exit;
}



//-------------------------------------------------------------------------------------
//  작업 종료
//-------------------------------------------------------------------------------------

?>

<script>location.replace("board.php");</script>

