<?
##################################################################################################################
##     페이지 코드번호 [메뉴의 선택위치 및 서브메뉴 보이기 등에 사용함]
$AC[0] = 5;
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################
?>


<div class="title float-wrap">
	<div class="float-left">
		<h1>게시판 관리</h1>
	</div>
	<div class="float-left title-text">
		<span class="">게시판의 설정사항을 변경합니다.</span>
	</div>
</div>


<?

//-------------------------------------------------------------------------------------
// GET 변수 검사
//-------------------------------------------------------------------------------------


if( empty($_GET['tbl']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

$tbl = $_GET['tbl'];


//-------------------------------------------------------------------------------------
//  board_conf 가져온다.
//-------------------------------------------------------------------------------------

$qry = " SELECT * FROM `". BBS_TBL_PREFIX ."conf` WHERE `bid`='" . $tbl . "' ";
$res = mysql_query( $qry );
$rows = mysql_num_rows( $res );

if($rows<1) {
	echo "<script>alert( '" . __LINE__ . " 존재하지 않는 게시판 코드입니다.   '); history.back(); </script>\n";
	exit;
}

$row = mysql_fetch_array($res,MYSQL_ASSOC);

/*
?><xmp><?
print_r($row);
?></xmp><?
*/

# 제목 표시줄 설정값 : 단일 변수를 분리시킨다.
if(isset($row['is_title_set'])) {
    //echo $row['is_title_set'];

    if(strpos($row['is_title_set'], "subject") !== false) {
        $row['is_title_set_subject'] = "y";
    }
    if(strpos($row['is_title_set'], "name") !== false) {
        $row['is_title_set_name'] = "y";
    }
    if(strpos($row['is_title_set'], "date") !== false) {
        $row['is_title_set_date'] = "y";
    }
    if(strpos($row['is_title_set'], "read") !== false) {
        $row['is_title_set_read'] = "y";
    }
}


//-------------------------------------------------------------------------------------
//  이하... 출력 폼
//-------------------------------------------------------------------------------------

?>






<form name="conf_form" method="post" enctype="multipart/form-data" action="board_edit.action.php" onSubmit="return check_form(this);">


<div>
	<table class="table-edit">
		<!-- 칼럼 사이즈 조절-->
		<colgroup width="200">
		<colgroup width="">

		<tbody>

<?
/****** 기본 설정 *******/
?>
			<tr>
				<th>게시판 코드</th>
				<td><input type="text" name="bid" value="<?=$row['bid']?>" title="게시판 코드" size="60" readonly></td>
			</tr>
			<tr>
				<th>게시판 이름</th>
				<td><input type="text" name="bname" value="<?=$row['bname']?>" title="게시판 이름" size="60"></td>
			</tr>
			<tr>
				<th>게시판 관리자</th>
				<td>
					<input type="text" name="admin" size="20" maxlength="20" value="<?=$row['admin']?>" title="게시판 관리자"> 회원 아이디 입력 (1인만 가능함)
				</td>
			</tr>
			<tr>
				<th>스킨 선택</th>
				<td>
					<select name="skin"><?=create_select($SKIN,$row['skin'])?></select>
				</td>
			</tr>

			<tr>
				<th>상단 include 파일</th>
				<td>
					<input type="text" name="inc_header" size="50" maxlength="60" value="<?=$row['inc_header']?>" title="게시판 상단 파일">
					DocumentRoot로부터 절대경로로 표기한다. 예) <span class="dodgerblue">/include/bbs_header.php</span>
				</td>
			</tr>
			<tr>
				<th>하단 include 파일</th>
				<td>
					<input type="text" name="inc_footer" size="50" maxlength="60" value="<?=$row['inc_footer']?>" title="게시판 하단 파일">
					DocumentRoot로부터 절대경로로 표기한다. 예) <span class="dodgerblue">/include/bbs_footer.php</span>
				</td>
			</tr>


			<tr>
				<th>상단 HTML</th>
				<td>
					<textarea name="inc_header_html" id="txt_body_id" style="width:100%; height:150px; display:none;"><?=$row['inc_header_html']?></textarea>

					<script src="/SmartEditor/js/HuskyEZCreator.js" charset="utf-8"></script>
					<script>var g5_editor_url = "/SmartEditor";</script>
					<script>var g5_elPlaceHolder = "txt_body_id";</script>
					<script type="text/javascript">
					var oEditors = [];
					nhn.husky.EZCreator.createInIFrame({
						oAppRef: oEditors,
						elPlaceHolder: g5_elPlaceHolder,
							sSkinURI: "/SmartEditor/SmartEditor2Skin.html",
						htParams : {
							bUseToolbar : true,
							bUseVerticalResizer : true,
							bUseModeChanger : true,
							fOnBeforeUnload : function(){
								//alert("완료!");
							}
						},
						fOnAppLoad : function(){
							//예제 코드
							//oEditors.getById["wr_content"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
						},
						fCreator: "createSEditor2"
					});
					</script>

				</td>
			</tr>






<?
/****** 권한 설정 *******/
?>

			<tr>
				<th class="td-title">권한 설정</th>
				<td>&nbsp;</td>
			</tr>


			<tr>
				<th>목록</th>
				<td>
					<select name="priv_list">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_list'],true)?>
					</select>
				</td>
			</tr>
			<tr>
				<th>읽기</th>
				<td>
					<select name="priv_read">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_read'],true)?>
					</select>
				</td>
			</tr>
			<tr>
				<th>쓰기</th>
				<td>
					<select name="priv_write">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_write'],true)?>
					</select>
				</td>
			</tr>
			<tr>
				<th>답글쓰기</th>
				<td>
					<select name="priv_reply">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_reply'],true)?>
					</select>
					<select name="is_reply">
						<option value="y" <? if($row['is_reply']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_reply']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>파일 업로드</th>
				<td>
					<select name="is_file">
						<option value="y" <? if($row['is_file']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_file']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					파일첨부 최대수량
					<input type="text" name="is_file_cnt" size="3" maxlength="3" value="<?=$row['is_file_cnt']?>" title="파일첨부 최대 수량">
				</td>
			</tr>
			<tr>
				<th>파일 업로드 NEW</th>
				<td>
					<select name="is_file_new">
						<option value="y" <? if($row['is_file_new']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_file_new']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					<span class="dodgerblue">파일첨부 신형방식(html5, 끌어서 넣기). 이 설정은 구형의 파일업로드 방식에 우선 적용됨. (일부 스킨은 비적용)</span>
				</td>
			</tr>
			<tr>
				<th>파일 다운로드</th>
				<td>
					<select name="priv_download">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_download'],true)?>
					</select>
				</td>
			</tr>
			<tr>
				<th>링크</th>
				<td>
					<select name="priv_url">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_url'],true)?>
					</select>
					<select name="is_url">
						<option value="y" <? if($row['is_url']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_url']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					링크 최대수량
					<input type="text" name="is_url_cnt" size="3" maxlength="3" value="<?=$row['is_url_cnt']?>" title="링크 최대 수량">
				</td>
			</tr>
			<tr>
				<th>꼬릿말쓰기</th>
				<td>
					<select name="priv_comment">
						<option value="0">0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_comment'],true)?>
					</select>
					<select name="is_comment">
						<option value="y" <? if($row['is_comment']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_comment']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>접근차단</th>
				<td>
					<textarea name="block_ip" cols="40" rows="8" style='float:left;'><?=$row['block_ip']?></textarea>
					<div style='float:left; margin-left:10px;'>
					접근을 차단할 ip 목록을 아래와 같이 기록한다.<br><br>
					192.168.1.100<br>
					172.16.33.<br>
					10.200.<br>
					</div>
				</td>
			</tr>










<?
/****** 레이아웃 설정 *******/
?>

			<tr>
				<th class="td-title">레이아웃 설정</th>
				<td>&nbsp;</td>
			</tr>

			<tr>
				<th>비밀글</th>
				<td>
					<select name="is_secret">
						<option value="y" <? if($row['is_secret']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_secret']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>HTML</th>
				<td>
					<select name="is_html">
						<option value="y" <? if($row['is_html']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_html']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					(에디터 사용 여부)
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

					<select name="is_html_editor">
						<option value="">에디터 선택</option>
						<option value="smarteditor2" <? if($row['is_html_editor']=='smarteditor2') { ?>selected<? } ?>>smarteditor2</option>
						<option value="cheditor4" <? if($row['is_html_editor']=='cheditor4') { ?>selected<? } ?>>cheditor4</option>
					</select>
					(에디터 선택)
				</td>
			</tr>
			<tr>
				<th>태그</th>
				<td>
					<select name="is_tag">
						<option value="y" <? if($row['is_tag']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_tag']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>검색</th>
				<td>
					<select name="is_search">
						<option value="y" <? if($row['is_search']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_search']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>카테고리</th>
				<td>
					<select name="is_category">
						<option value="y" <? if($row['is_category']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_category']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					카테고리
					<input type="text" name="category" size="80" maxlength="200" value="<?=$row['category']?>" title="카테고리"> 예: 가나다;라마바
				</td>
			</tr>
			<tr>
				<th>게시판의 가로 너비</th>
				<td>
					<input type="text" name="num_width" size="6" maxlength="6" value="<?=$row['num_width']?>" title="게시판의 가로 너비"> 게시판의 가로 폭 너비 (100 이하는 %로, 100 초과는 pixel 로 계산됨)
				</td>
			</tr>
			<tr>
				<th>이미지의 가로 너비</th>
				<td>
					<input type="text" name="num_image_width" size="6" maxlength="6" value="<?=$row['num_image_width']?>" title="이미지의 가로 너비"> 이미지의 가로 폭 너비 (pixel)
				</td>
			</tr>
			<tr>
				<th>제목의 길이</th>
				<td>
					<input type="text" name="num_subject" size="6" maxlength="6" value="<?=$row['num_subject']?>" title="제목의 길이"> 리스트에 뿌려줄 제목의 길이를 자동으로 자른다.
				</td>
			</tr>
			<tr>
				<th>페이지당 글 수</th>
				<td>
					<input type="text" name="num_list" size="6" maxlength="6" value="<?=$row['num_list']?>" title="페이지당 글 수"> 한 페이지에 표시할 게시물 숫자
				</td>
			</tr>
			<tr>
				<th>갤러리 모드</th>
				<td>
					<select name="is_gallery">
						<option value="y" <? if($row['is_gallery']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_gallery']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					한 줄에 표시할 갤러리 숫자
					<input type="text" name="is_gallery_cnt" size="6" maxlength="6" value="<?=$row['is_gallery_cnt']?>" title="갤러리 표시 갯수">
				</td>
			</tr>
			<tr>
				<th>갤러리 목록 이미지</th>
				<td>
					<input type="text" name="is_gallery_img_w" size="6" maxlength="6" value="<?=$row['is_gallery_img_w']?>" title="갤러리 목록 이미지"> 이미지의 가로 폭 너비 (pixel)
				</td>
			</tr>
			<tr>
				<th>읽기 화면에 목록</th>
				<td>
					<select name="is_read_list">
						<option value="y" <? if($row['is_read_list']=='y') { ?>selected<? } ?>>사용함</option>
						<option value="n" <? if($row['is_read_list']=='n') { ?>selected<? } ?>>사용하지 않음</option>
					</select>
					게시물 읽기 화면 하단에 목록을 추가

				</td>
			</tr>










<?
/****** 제목줄 설정 *******/
?>


<?
$array_field = array(
	"subject" => "제목",
	"name" => "글쓴이",
	"date" => "작성일자",
	"read" => "조회수",
);
?>
			<tr>
				<th class="td-title">제목줄 표시 설정</th>
				<td><span class="dodgerblue">제목줄 표시 설정은 v 2.0 이상의 스킨에서만 올바르게 작동합니다. 구버전 스킨은 HTML 수정이 필요합니다. (목록페이지, 읽기페이지)</span></th>
			</tr>
<?
foreach($array_field as $key=>$val) {
?>
			<tr>
				<th><?=$val?></th>
				<td>
                    <input type="checkbox" name="is_title_set_<?=$key?>" id="is_title_set_<?=$key?>" class="css-checkbox" value="y" <? if($row['is_title_set_'.$key]=='y') { ?>checked<? } ?>>
                    <label for="is_title_set_<?=$key?>" class="css-checkbox-label size13px">표시함</label>
				</td>
			</tr>
<?
} // end for;
?>


<?
/****** 기본항목 설정 *******/
?>


<?
$array_field = array(
	"mail" => "E-mail",
	"tel" => "전화번호",
	"fax" => "팩스번호",
	"mobile" => "휴대전화",
	"home" => "홈페이지",
    "date" => "작성일자",
);
?>
			<tr>
				<th class="td-title">기본항목 설정</th>
				<td><span class="dodgerblue">기본항목 설정은 v 2.0 이상의 스킨에서만 올바르게 작동합니다. 구버전 스킨은 HTML 수정이 필요합니다.</span></th>
			</tr>
<?
foreach($array_field as $key=>$val) {
?>
			<tr>
				<th><?=$val?></th>
				<td>
                    <input type="checkbox" name="is_field_<?=$key?>" id="is_field_<?=$key?>" class="css-checkbox" value="y" <? if($row['is_field_'.$key]=='y') { ?>checked<? } ?>>
                    <label for="is_field_<?=$key?>" class="css-checkbox-label size13px">표시함</label>

					<!-- <select name="is_field_<?=$key?>">
                        <option value="y" <? if($row['is_field_'.$key]=='y') { ?>selected<? } ?>>표시함</option>
                        <option value="n" <? if($row['is_field_'.$key]=='n') { ?>selected<? } ?>>표시하지 않음</option>
                    </select> -->
				</td>
			</tr>
<?
} // end for;
?>








<?
/****** 기타 설정 *******/
?>

			<tr>
				<th class="td-title">기타항목 설정</th>
				<td><span class="dodgerblue">기타항목 설정은 현재 일부 스킨에서만 구현된 기능입니다(예: notice_v2, board_v2). 기타항목은 텍스트 입력칸(&lt;input type="text"&gt;)으로 표시됩니다.</span></td>
			</tr>
<?
for($i=1; $i<=10; $i++) {
?>
			<tr>
				<th>기타항목 <?=$i?></th>
				<td>
                    <input type="checkbox" name="misc_<?=sprintf("%02s",$i)?>_yn" id="misc_<?=sprintf("%02s",$i)?>_yn" class="css-checkbox" value="y" <? if($row['misc_'.sprintf("%02s",$i).'_yn']=='y') { ?>checked<? } ?>>
                    <label for="misc_<?=sprintf("%02s",$i)?>_yn" class="css-checkbox-label size13px">표시함</label>

					<input type="text" name="misc_<?=sprintf("%02s",$i)?>" value="<?=$row['misc_'.sprintf("%02s",$i)]?>" title="기타항목 <?=$i?>" size="60">
				</td>
			</tr>
<?
} // end for;
?>




		</tbody>
	</table>
</div>




<div style="text-align:right;">
	<span class="button"><input type="submit" value="저장"></span>
	<span class="button"><input type="button" value="취소" onClick="history.back();" title="back"></span>
	<span class="button"><input type="button" value="목록" onClick="location.href='board.php';"></span>
</div>


</form>



<script>
function check_form(f) {
	var str = '';
	for(i=0; i<f.elements.length; i++) {
		str += f.elements[i].name + ': '+ f.elements[i].tagName + ', '+ f.elements[i].type + '\n';
	}
	//alert(str);

	// editor
	try{
		oEditors.getById["txt_body_id"].exec("UPDATE_CONTENTS_FIELD", []);
	}catch(e){}

	//return false;
}
</script>





<?
##################################################################################################################
##     HTML 출력 부분의 마지막
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_foot.php";
##################################################################################################################
?>