<?
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################



//print_r($_POST);


//-------------------------------------------------------------------------------------
// GET 변수 검사
//-------------------------------------------------------------------------------------


if( empty($_POST['table_from']) ) {
	echo "<script>alert( '" . __LINE__ . " 원본 게시판의 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}
if( empty($_POST['table_to']) ) {
	echo "<script>alert( '" . __LINE__ . " 생성할 게시판의 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

$pattern = "/^[-a-z0-9_]{2,20}$/";

if( preg_match( $pattern,$_POST['table_to']) ) {
} else {
	echo "<script>alert( '" . __LINE__ . " 생성할 게시판의 코드가 올바르지 않습니다.   '); history.back(); </script>\n";
	exit;
}

if( empty($_POST['table_name']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 제목이 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}




$table_from = $_POST['table_from'];
$table_to = $_POST['table_to'];
$table_name = $_POST['table_name'];


//-------------------------------------------------------------------------------------
// 테이블 코드 중복 검사
//-------------------------------------------------------------------------------------

$qry = " SELECT COUNT(*) FROM `". BBS_TBL_PREFIX ."conf` WHERE `bid`='" . $table_to . "' ";
$res = mysql_query( $qry );
$rows = mysql_result( $res, 0, 0 );

if($rows>0) {
	echo "<script>alert( '" . __LINE__ . " 생성할 게시판의 코드가 이미 존재합니다.   '); history.back(); </script>\n";
	exit;
}




//-------------------------------------------------------------------------------------
//  board_conf 생성
//-------------------------------------------------------------------------------------

// 원본 설정을 가져온다.

$qry = " SELECT * FROM `". BBS_TBL_PREFIX ."conf` WHERE `bid`='" . $table_from . "' ";
$res = mysql_query( $qry );
$rows = mysql_num_rows( $res );

if($rows<1) {
	echo "<script>alert( '" . __LINE__ . " 원본 게시판의 코드가 존재하지 않습니다.   '); history.back(); </script>\n";
	exit;
}

$row = mysql_fetch_array($res,MYSQL_ASSOC);

$_INSERT = array();
$_INSERT['bid'] = $table_to;
$_INSERT['bname'] = $table_name;

// 사본을 넣기 위한 배열 작업

foreach( $row as $key=>$val ) {
	if($key=='bid') continue;
	if($key=='bname') continue;

	$_INSERT[ $key ] = $val;
}

// 입력 SQL문 생성

$query = " INSERT INTO `". BBS_TBL_PREFIX ."conf` SET ";
$idx = 0;
foreach( $_INSERT as $key=>$val ) {
	if($idx>0) $query.= ", ";
	$query .= "`".$key."`='".$val."'";
	$idx++;
}
//$query .= " WHERE staff_id='".$_POST['staff_id']."' ";
//echo $query."<br><br>\n"; exit;


$result = mysql_query($query);

if (!$result) {
	//echo ("<script>alert('작업 오류입니다.\\n\\n에러코드 = DB_".__LINE__."     '); history.back()</script>\n\n");
	echo mysql_error();
	echo "<br><br>\n";
	echo $query; exit;
}




//-------------------------------------------------------------------------------------
//  board_conf 레코드 정렬
//-------------------------------------------------------------------------------------

$qry_alter = "ALTER TABLE `". BBS_TBL_PREFIX ."conf` ORDER BY `bid`";
$res_alter = mysql_query($qry_alter);
if (!$res) {
	//echo ("<script>alert('작업 오류입니다.\\n\\n에러코드 = DB_".__LINE__."     '); history.back()</script>\n\n");
	echo mysql_error();
	echo "<br><br>\n";
	echo $qry_alter; exit;
}




//-------------------------------------------------------------------------------------
// 게시판 생성
//-------------------------------------------------------------------------------------

/*
	통합DB 사용으로 변경됨. 테이블을 생성하지 않음
*/



//-------------------------------------------------------------------------------------
// 코멘트테이블 생성
//-------------------------------------------------------------------------------------

/*
	통합DB 사용으로 변경됨. 테이블을 생성하지 않음
*/




//-------------------------------------------------------------------------------------
//  작업 종료
//-------------------------------------------------------------------------------------

?>

<script>location.replace("board.php");</script>

