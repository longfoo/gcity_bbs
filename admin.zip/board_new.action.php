<?
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################



//print_r($_POST); exit;


//-------------------------------------------------------------------------------------
// POST 변수 검사
//-------------------------------------------------------------------------------------


if( empty($_POST['bid']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

if( empty($_POST['board_id']) or empty($_POST['board_id_check']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판 코드의 중복 체크가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

if( $_POST['board_id'] != $_POST['bid'] ) {
	echo "<script>alert( '" . __LINE__ . " 게시판 코드의 중복 체크가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}

$pattern = "/^[-a-z0-9_]{2,20}$/";

if( preg_match( $pattern,$_POST['bid']) ) {
} else {
	echo "<script>alert( '" . __LINE__ . " 게시판의 코드가 올바르지 않습니다.   '); history.back(); </script>\n";
	exit;
}


if( empty($_POST['bname']) ) {
	echo "<script>alert( '" . __LINE__ . " 게시판의 제목이 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}


//-------------------------------------------------------------------------------------
// 테이블 코드 중복 검사
//-------------------------------------------------------------------------------------


$qry = " SELECT COUNT(*) FROM `jboard_conf` WHERE `bid`='" . $_POST['bid'] . "' ";
$res = mysql_query( $qry );
$rows = mysql_result( $res, 0, 0 );

if($rows>0) {
	echo "<script>alert( '" . __LINE__ . " 생성할 게시판의 코드가 이미 존재합니다.   '); history.back(); </script>\n";
	exit;
}




//-------------------------------------------------------------------------------------
//  board_conf 생성
//-------------------------------------------------------------------------------------

$_INSERT = array();


$_INSERT['bid'] = $_POST['bid'];
$_INSERT['bname'] = $_POST['bname'];

// 사본을 넣기 위한 배열 작업

foreach( $_POST as $key=>$val ) {
	if($key=='tbl') continue;
	if($key=='bid') continue;
	if($key=='board_id') continue; // 관리목적의 변수는 버린다.
	if($key=='board_id_check') continue; // 관리목적의 변수는 버린다.

	$_INSERT[ $key ] = $val;
}

// 입력 SQL문 생성

$query = " INSERT INTO `". BBS_TBL_PREFIX ."conf` SET ";
//$query = " UPDATE `". BBS_TBL_PREFIX ."conf` SET ";
$idx = 0;
foreach( $_INSERT as $key=>$val ) {
	if($idx>0) $query.= ", ";
	$query .= "`".$key."`='".$val."'";
	$idx++;
}
//$query .= " WHERE `bid`='".$_POST['bid']."' ";
//echo $query."<br><br>\n"; exit;


$result = mysql_query($query);

if (!$result) {
	//echo ("<script>alert('작업 오류입니다.\\n\\n에러코드 = DB_".__LINE__."     '); history.back()</script>\n\n");
	echo mysql_error();
	echo "<br><br>\n";
	echo $query; exit;
}


//-------------------------------------------------------------------------------------
//  board_conf 레코드 정렬
//-------------------------------------------------------------------------------------

$qry_alter = "ALTER TABLE `". BBS_TBL_PREFIX ."conf` ORDER BY `bid`";
$res_alter = mysql_query($qry_alter);
if (!$res_alter) {
	//echo ("<script>alert('작업 오류입니다.\\n\\n에러코드 = DB_".__LINE__."     '); history.back()</script>\n\n");
	echo mysql_error();
	echo "<br><br>\n";
	echo $qry_alter; exit;
}




//-------------------------------------------------------------------------------------
// 게시판 생성
//-------------------------------------------------------------------------------------


/*
	통합DB 사용으로 변경됨. 테이블을 생성하지 않음
*/


//-------------------------------------------------------------------------------------
// 코멘트테이블 생성
//-------------------------------------------------------------------------------------


/*
	통합DB 사용으로 변경됨. 테이블을 생성하지 않음
*/



//-------------------------------------------------------------------------------------
//  작업 종료
//-------------------------------------------------------------------------------------

?>

<script>location.replace("board.php");</script>

