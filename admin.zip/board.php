<?
##################################################################################################################
##     페이지 코드번호 [메뉴의 선택위치 및 서브메뉴 보이기 등에 사용함]
$AC[0] = 5;
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################








#--------------------------------------------------------------------------------------------------
# 전체레코드 카운팅
#--------------------------------------------------------------------------------------------------
$qry = " SELECT COUNT(*) FROM `". BBS_TBL_PREFIX ."conf` " . $qry_search;
$res = mysql_query( $qry );
$rows = mysql_result( $res, 0, 0 );


include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/class_page.php";

# 페이지 설정
# 1. 한 페이지에 보여질 게시물의 수
$page_size = 30;
# 2. 페이지 나누기에 표시될 페이지의 수
$page_list_size = 10;

// 페이지 링크에 따라붙을 변수들 (연관배열로 생성)
$page_array = array("tbl"=>$_GET['tbl'], "s_cat"=>$_GET['s_cat'], "s_sel"=>$_GET['s_sel'], "s_key"=>$_GET['s_key'], );

$page = $_GET['page'] ? $_GET['page'] : 1;

$self = $_SERVER['PHP_SELF']; // 일반적인 경우
//$self = 'list.php'; // 특별한 경우

// 페이지 관련 변수 설정
// new pageSet( 전체레코드수, 현재페이지번호, $page_array, 목록수, 페이지수 )
$pg = new pageSet($rows, $page, $page_array, $page_size, $page_list_size, $self);

##--------------------------------------------------------------------------------------------------
?>



<div class="title float-wrap">
	<div class="float-left">
		<h1>게시판 관리</h1>
	</div>
	<div class="float-left title-text">
		<span class="">게시판을 관리합니다.</span>
	</div>
</div>

<div class="div-topmenu float-wrap">
	<div class="float-left">
	</div>
	<div class="float-right">
		<span class="button"><a href="board_new.php">게시판 생성</a></span>
	</div>

</div>





<form name="board_list" method="post" action="board.action.php" onSubmit="return check_board_list(this);">
<input type="hidden" name="mode" value="b">

<div>
	<table class="table-list">
		<thead>
			<tr>
				<th>코드</th>
				<th>게시판 제목</th>
				<th>스킨</th>
				<th>바로가기</th>
				<th>관리자</th>
				<th>전체글수</th>
				<th>꼬리글수</th>
				<th>쓰기</th>
				<th>답글</th>
				<th>꼬리글</th>
				<th colspan="3">관리</th>
			</tr>
		</thead>
		<tbody>


<?
$td_colspan = "13";

##--------------------------------------------------------------------------------------------------
// 게시판 설정을 전부 가져온다.
$qry = "SELECT * FROM `". BBS_TBL_PREFIX ."conf` ORDER BY `bid`  ";
$res = mysql_query($qry);

if( !$res ) {
	echo mysql_error();
}

if( mysql_num_rows($res)<1 ) {
?>

			<tr>
				<td colspan='<?=$td_colspan?>'>No Records.</td>
			</tr>
<?

} else {

	while( $row = mysql_fetch_array($res,MYSQL_ASSOC) ) {

		// 게시판별 글 수
		$qry_count = "SELECT COUNT(*) FROM `". BBS_BRD_DATA . "` WHERE `bid`='" . $row['bid'] . "' ";
		//echo $qry_count, "<br>", PHP_EOL;
		$res_count = mysql_query($qry_count);
		$row_count = mysql_result($res_count,0,0);

		// 게시판별 글 수
		$qry_count = "SELECT COUNT(*) FROM `". BBS_CMT_DATA . "` WHERE `bid`='" . $row['bid'] . "' ";
		$res_count = mysql_query($qry_count);
		$cmt_count = mysql_result($res_count,0,0);

?>

			<tr>
				<td class="center"><?=$row['bid']?><input type="hidden" name="bid[]" value="<?=$row['bid']?>"></td>
				<td><?=$row['bname']?></td>
				<td class="center"><select name='skin[]'><?=create_select($SKIN,$row['skin'])?></select></td>
				<td class="center">
					<span class="button"><a href="/bbs/list.php?tbl=<?=$row['bid']?>" target="_blank">보기</a></span>
				</td>
				<td class="center"><input type="text" name="admin[]" value="<?=$row['admin']?>" size="10"></td>
				<td class="center"><?=number_format($row_count)?></td>
				<td class="center"><?=number_format($cmt_count)?></td>
				<td class="center">
					<select name='priv_write[]'>
						<option value='0'>0 비회원</option><?=create_select($CONFIG['mb_level'],$row['priv_write'],true)?>
					</select>
				</td>
				<td class="center"><select name='is_reply[]'><?=create_select($array_yn,$row['is_reply'])?></select></td>
				<td class="center"><select name='is_comment[]'><?=create_select($array_yn,$row['is_comment'])?></select></td>
				<td class="center">
					<span class="button"><a href="board_edit.php?tbl=<?=$row['bid']?>" title="환경 설정">설정</a></span>
				</td>
				<td class="center">
					<span class="button"><a href="board_copy.php?tbl=<?=$row['bid']?>" title="구조 복사">복사</a></span>
				</td>
				<td class="center">
					<span class="button"><a href="board_delete.php?tbl=<?=$row['bid']?>" title="삭제" onClick="if(confirm('게시판을 삭제한 후에는 복구할 수 없습니다. \n\n모든 게시물과 답글, 꼬릿글, 첨부파일 등이 삭제됩니다.\n\n그래도 게시판을 삭제하시겠습니까?     ')) { location.href=this.href; return false; } else { return false; }">삭제</a></span>
				</td>
			</tr>
<?
		$pg->no--;
	}
	// end while;
}
?>

		</tbody>
	</table>
</div>


<div class="float-wrap">
	<div class="float-left">
	</div>

	<div class="float-right">
		<span class="button black"><input type="submit" value="전체 수정"></span> &nbsp;
		<span class="button"><input type="reset" value="취소"></span>
	</div>
</div>

</form>




<script>
function check_board_list(f) {
	if( confirm('전체 게시판의 설정값을 변경하시겠습니까?     ') ) {
		return;
	} else {
		return false;
	}
}
</script>



<?
##################################################################################################################
##     HTML 출력 부분의 마지막
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_foot.php";
##################################################################################################################
?>