<?
##################################################################################################################
##     페이지 코드번호 [메뉴의 선택위치 및 서브메뉴 보이기 등에 사용함]
$AC[0] = 5;
##################################################################################################################
##     페이지 공통 라이브러리
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/database.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/library.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/session.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/lib/escape_get_post.php";
##################################################################################################################
##     접근 권한 체크
##################################################################################################################
define("_AUTH_", "ADMIN");
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/access.php";
##################################################################################################################
##     게시판 공통 라이브러리
##################################################################################################################
//include_once $_SERVER['DOCUMENT_ROOT'] . "/bbs/bbs_config.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/inc_board.php";
##################################################################################################################
##     HTML 출력 부분의 시작
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_head.php";
##################################################################################################################
?>


<div class="title float-wrap">
	<div class="float-left">
		<h1>게시판 복사</h1>
	</div>
	<div class="float-left title-text">
		<span class="">원본 게시판과 동일한 설정으로 신규게시판을 생성합니다. 데이터는 복사되지 않습니다.</span>
	</div>
</div>





<?
//-------------------------------------------------------------------------------------
// GET 변수 검사
//-------------------------------------------------------------------------------------

$tbl = $_REQUEST['tbl'];

if( empty($tbl) ) {
	echo "<script>alert('게시판 코드가 누락되었습니다.   '); history.back(); </script>\n";
	exit;
}




//-------------------------------------------------------------------------------------
// 입력 폼
//-------------------------------------------------------------------------------------

?>


<form name="write_form" method="post" action="board_copy.action.php" onSubmit="return check_form(this);">

<input type="hidden" name="tbl" value="<?=$_GET['tbl']?>">

<div>
	<table class="table-edit">
		<!-- 칼럼 사이즈 조절-->
		<colgroup width="200">
		<colgroup width="">

		<tr>
			<th>원본 테이블</th>
			<td><input type="text" name="table_from" size="20" readonly value="<?=$tbl?>"></td>
		</tr>

		<tr>
			<th>생성할 테이블</th>
			<td><input type="text" name="table_to" size="20" maxlength="20"> (영문 소문자, 숫자, _ 만 허용됨)</td>
		</tr>

		<tr>
			<th>테이블 제목</th>
			<td><input type="text" name="table_name" size="60" maxlength="60"></td>
		</tr>
	</table>
</div>

<div style="text-align:right;">
	<span class="button"><input type="submit" value="저장"></span>
	<span class="button"><input type="button" value="취소" onClick="history.back();" title="back"></span>
	<span class="button"><input type="button" value="목록" onClick="location.href='board.php';"></span>
</div>

</form>



<script>
function check_form(f) {
	if(f.table_from && f.table_from.value=='') {
		alert('원본 테이블 코드를 입력하십시오. ');
		return false;
	}
	if(f.table_to && f.table_to.value=='') {
		alert('생성할 테이블 코드를 입력하십시오. ');
		return false;
	}
	if(f.table_name && f.table_name.value=='') {
		alert('테이블 제목을 입력하십시오. ');
		return false;
	}
}
</script>






<?
##################################################################################################################
##     HTML 출력 부분의 마지막
##################################################################################################################
include_once $_SERVER['DOCUMENT_ROOT'] . "/admin/admin_foot.php";
##################################################################################################################
?>